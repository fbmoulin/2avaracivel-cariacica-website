/**
 * Script para alternância entre GIF e imagens estáticas no tutorial do Zoom
 * Implementa controles avançados para acessibilidade e preferências do usuário
 */

document.addEventListener('DOMContentLoaded', function() {
    // Verificar se estamos na página do tutorial do Zoom
    const isTutorialPage = document.querySelector('.tutorial-section');
    if (!isTutorialPage) return;
    
    // Elementos principais
    const tutorialGif = document.querySelector('.tutorial-gif');
    const tabButtons = document.querySelectorAll('[data-bs-toggle="tab"]');
    const animatedTab = document.getElementById('animated-tab');
    const stepByStepTab = document.getElementById('step-by-step-tab');
    
    // Verificar preferências do usuário
    checkUserPreferences();
    
    // Adicionar controles de acessibilidade para o GIF
    if (tutorialGif) {
        addGifAccessibilityControls();
    }
    
    // Adicionar indicador de carregamento para o GIF
    if (tutorialGif) {
        addLoadingIndicator();
    }
    
    // Adicionar botão para alternar entre modos
    addToggleModeButton();
    
    /**
     * Verifica preferências do usuário e ajusta a exibição inicial
     */
    function checkUserPreferences() {
        // Verificar preferência de movimento reduzido
        const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        
        // Se o usuário prefere movimento reduzido, mostrar imagens estáticas por padrão
        if (prefersReducedMotion && stepByStepTab) {
            // Ativar a aba de passo a passo
            setTimeout(() => {
                const tabInstance = new bootstrap.Tab(stepByStepTab);
                tabInstance.show();
                
                // Anunciar para leitores de tela
                announceToScreenReader('Tutorial exibido em modo passo a passo com imagens estáticas devido à sua preferência de movimento reduzido');
            }, 500);
        }
        
        // Adicionar listener para mudanças na preferência de movimento reduzido
        window.matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change', (e) => {
            if (e.matches && stepByStepTab) {
                // Ativar a aba de passo a passo
                const tabInstance = new bootstrap.Tab(stepByStepTab);
                tabInstance.show();
                
                // Anunciar para leitores de tela
                announceToScreenReader('Alternando para modo passo a passo com imagens estáticas');
            }
        });
    }
    
    /**
     * Adiciona controles de acessibilidade para o GIF
     */
    function addGifAccessibilityControls() {
        // Criar contêiner para controles
        const controlsContainer = document.createElement('div');
        controlsContainer.className = 'tutorial-controls';
        controlsContainer.setAttribute('aria-label', 'Controles do tutorial animado');
        
        // Criar botão de pausa/reprodução
        const toggleButton = document.createElement('button');
        toggleButton.className = 'tutorial-control-btn';
        toggleButton.innerHTML = '<i class="fas fa-pause me-2"></i>Pausar animação';
        toggleButton.setAttribute('aria-label', 'Pausar animação do tutorial');
        
        // Criar botão para alternar para imagens estáticas
        const switchButton = document.createElement('button');
        switchButton.className = 'tutorial-control-btn';
        switchButton.innerHTML = '<i class="fas fa-images me-2"></i>Ver passo a passo';
        switchButton.setAttribute('aria-label', 'Alternar para tutorial passo a passo com imagens estáticas');
        
        // Adicionar botões ao contêiner
        controlsContainer.appendChild(toggleButton);
        controlsContainer.appendChild(switchButton);
        
        // Inserir controles após o GIF
        const gifContainer = tutorialGif.parentElement;
        gifContainer.parentElement.insertBefore(controlsContainer, gifContainer.nextSibling);
        
        // Salvar URL original do GIF
        const originalSrc = tutorialGif.src;
        let isPaused = false;
        
        // Manipulador para botão de pausa/reprodução
        toggleButton.addEventListener('click', function() {
            if (isPaused) {
                // Reproduzir GIF
                tutorialGif.src = originalSrc;
                toggleButton.innerHTML = '<i class="fas fa-pause me-2"></i>Pausar animação';
                toggleButton.setAttribute('aria-label', 'Pausar animação do tutorial');
                announceToScreenReader('Animação do tutorial reproduzindo');
            } else {
                // Pausar GIF (substituindo por um frame estático)
                createStaticFrame();
                toggleButton.innerHTML = '<i class="fas fa-play me-2"></i>Reproduzir animação';
                toggleButton.setAttribute('aria-label', 'Reproduzir animação do tutorial');
                announceToScreenReader('Animação do tutorial pausada');
            }
            isPaused = !isPaused;
        });
        
        // Manipulador para botão de alternar para imagens estáticas
        switchButton.addEventListener('click', function() {
            // Ativar a aba de passo a passo
            if (stepByStepTab) {
                const tabInstance = new bootstrap.Tab(stepByStepTab);
                tabInstance.show();
                announceToScreenReader('Alternando para modo passo a passo com imagens estáticas');
            }
        });
        
        // Função para criar um frame estático do GIF
        function createStaticFrame() {
            // Criar um canvas para capturar o frame atual
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            
            // Definir dimensões do canvas
            canvas.width = tutorialGif.naturalWidth || tutorialGif.width;
            canvas.height = tutorialGif.naturalHeight || tutorialGif.height;
            
            // Desenhar o frame atual no canvas
            context.drawImage(tutorialGif, 0, 0, canvas.width, canvas.height);
            
            // Substituir o GIF pelo frame estático
            try {
                tutorialGif.src = canvas.toDataURL('image/png');
            } catch (e) {
                console.error('Erro ao criar frame estático:', e);
                // Fallback: usar a primeira imagem estática do tutorial
                const firstStepImage = document.querySelector('.step-image');
                if (firstStepImage) {
                    tutorialGif.src = firstStepImage.src;
                }
            }
        }
    }
    
    /**
     * Adiciona indicador de carregamento para o GIF
     */
    function addLoadingIndicator() {
        // Criar indicador de carregamento
        const loadingIndicator = document.createElement('div');
        loadingIndicator.className = 'loading-indicator';
        loadingIndicator.innerHTML = '<div class="loading-spinner"></div>';
        loadingIndicator.setAttribute('aria-label', 'Carregando animação do tutorial');
        
        // Adicionar ao contêiner do GIF
        const gifContainer = tutorialGif.parentElement;
        gifContainer.style.position = 'relative';
        gifContainer.appendChild(loadingIndicator);
        
        // Ocultar indicador quando o GIF estiver carregado
        tutorialGif.addEventListener('load', function() {
            loadingIndicator.style.display = 'none';
            announceToScreenReader('Animação do tutorial carregada');
        });
        
        // Mostrar indicador se o GIF demorar para carregar
        setTimeout(() => {
            if (getComputedStyle(loadingIndicator).display !== 'none') {
                announceToScreenReader('A animação do tutorial está carregando. Por favor, aguarde ou alterne para o modo passo a passo.');
            }
        }, 3000);
    }
    
    /**
     * Adiciona botão para alternar entre modos de tutorial
     */
    function addToggleModeButton() {
        // Verificar se as abas existem
        if (!animatedTab || !stepByStepTab) return;
        
        // Adicionar botão flutuante para alternar entre modos
        const toggleButton = document.createElement('button');
        toggleButton.className = 'btn btn-primary btn-sm position-fixed tutorial-toggle-mode';
        toggleButton.style.bottom = '20px';
        toggleButton.style.right = '20px';
        toggleButton.style.zIndex = '1000';
        toggleButton.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
        toggleButton.style.borderRadius = '50px';
        toggleButton.style.padding = '8px 16px';
        
        // Definir texto inicial com base na aba ativa
        if (animatedTab.classList.contains('active')) {
            toggleButton.innerHTML = '<i class="fas fa-images me-2"></i>Ver passo a passo';
            toggleButton.setAttribute('aria-label', 'Alternar para tutorial passo a passo com imagens estáticas');
        } else {
            toggleButton.innerHTML = '<i class="fas fa-film me-2"></i>Ver animação';
            toggleButton.setAttribute('aria-label', 'Alternar para tutorial animado');
        }
        
        // Adicionar ao corpo do documento
        document.body.appendChild(toggleButton);
        
        // Manipulador de clique para alternar entre modos
        toggleButton.addEventListener('click', function() {
            if (animatedTab.classList.contains('active')) {
                // Alternar para passo a passo
                const tabInstance = new bootstrap.Tab(stepByStepTab);
                tabInstance.show();
                toggleButton.innerHTML = '<i class="fas fa-film me-2"></i>Ver animação';
                toggleButton.setAttribute('aria-label', 'Alternar para tutorial animado');
                announceToScreenReader('Alternando para modo passo a passo com imagens estáticas');
            } else {
                // Alternar para animado
                const tabInstance = new bootstrap.Tab(animatedTab);
                tabInstance.show();
                toggleButton.innerHTML = '<i class="fas fa-images me-2"></i>Ver passo a passo';
                toggleButton.setAttribute('aria-label', 'Alternar para tutorial passo a passo com imagens estáticas');
                announceToScreenReader('Alternando para modo animado');
            }
        });
        
        // Atualizar botão quando as abas mudarem
        tabButtons.forEach(button => {
            button.addEventListener('shown.bs.tab', function(e) {
                if (e.target.id === 'animated-tab') {
                    toggleButton.innerHTML = '<i class="fas fa-images me-2"></i>Ver passo a passo';
                    toggleButton.setAttribute('aria-label', 'Alternar para tutorial passo a passo com imagens estáticas');
                } else {
                    toggleButton.innerHTML = '<i class="fas fa-film me-2"></i>Ver animação';
                    toggleButton.setAttribute('aria-label', 'Alternar para tutorial animado');
                }
            });
        });
    }
    
    /**
     * Anuncia mensagem para leitores de tela
     */
    function announceToScreenReader(message) {
        // Verificar se já existe um anunciador
        let announcer = document.getElementById('screen-reader-announcer');
        
        if (!announcer) {
            // Criar elemento anunciador
            announcer = document.createElement('div');
            announcer.id = 'screen-reader-announcer';
            announcer.setAttribute('aria-live', 'polite');
            announcer.setAttribute('aria-atomic', 'true');
            announcer.style.position = 'absolute';
            announcer.style.left = '-10000px';
            announcer.style.top = 'auto';
            announcer.style.width = '1px';
            announcer.style.height = '1px';
            announcer.style.overflow = 'hidden';
            
            // Adicionar ao corpo do documento
            document.body.appendChild(announcer);
        }
        
        // Limpar conteúdo anterior e adicionar nova mensagem
        announcer.textContent = '';
        
        setTimeout(() => {
            announcer.textContent = message;
        }, 100);
    }
});
