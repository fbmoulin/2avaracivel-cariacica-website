/**
 * Script de acessibilidade para tutoriais visuais - 2ª Vara Cível de Cariacica
 * Implementa funcionalidades de acessibilidade para tutoriais com imagens e GIFs
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elementos principais
    const tutorialGif = document.querySelector('.tutorial-gif');
    const stepImages = document.querySelectorAll('.step-image');
    const tabButtons = document.querySelectorAll('[data-bs-toggle="tab"]');
    
    // Configuração para imagens ampliáveis
    setupImageEnlargement();
    
    // Configuração para anúncios de mudança de aba
    setupTabAnnouncements();
    
    // Configuração para controle de GIF (pausa/reprodução)
    setupGifControls();
    
    // Configuração para navegação por teclado
    setupKeyboardNavigation();
    
    // Configuração para descrições detalhadas
    setupDetailedDescriptions();
    
    /**
     * Configura funcionalidade de ampliação de imagens
     */
    function setupImageEnlargement() {
        if (!stepImages.length) return;
        
        stepImages.forEach(image => {
            // Adicionar atributos de acessibilidade
            image.setAttribute('role', 'button');
            image.setAttribute('tabindex', '0');
            image.setAttribute('aria-label', `${image.alt} (Clique ou pressione Enter para ampliar)`);
            image.setAttribute('title', 'Clique para ampliar');
            
            // Estilo visual para indicar interatividade
            image.style.cursor = 'zoom-in';
            
            // Manipuladores de eventos para mouse e teclado
            image.addEventListener('click', handleImageClick);
            image.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    handleImageClick.call(this);
                }
            });
        });
    }
    
    /**
     * Manipula o clique em uma imagem para ampliação
     */
    function handleImageClick() {
        // Criar modal para visualização ampliada
        const modal = document.createElement('div');
        modal.className = 'image-preview-modal';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'preview-title');
        
        // Criar título oculto para acessibilidade
        const title = document.createElement('h2');
        title.id = 'preview-title';
        title.textContent = `Imagem ampliada: ${this.alt}`;
        title.style.position = 'absolute';
        title.style.left = '-10000px';
        title.style.top = 'auto';
        title.style.width = '1px';
        title.style.height = '1px';
        title.style.overflow = 'hidden';
        
        // Criar imagem ampliada
        const previewImage = document.createElement('img');
        previewImage.src = this.src;
        previewImage.alt = this.alt;
        previewImage.className = 'preview-image';
        
        // Adicionar botão de fechar
        const closeButton = document.createElement('button');
        closeButton.innerHTML = '&times;';
        closeButton.className = 'modal-close-button';
        closeButton.setAttribute('aria-label', 'Fechar imagem ampliada');
        
        // Adicionar elementos ao modal
        modal.appendChild(title);
        modal.appendChild(previewImage);
        modal.appendChild(closeButton);
        
        // Adicionar modal ao corpo do documento
        document.body.appendChild(modal);
        
        // Animar abertura
        setTimeout(() => {
            modal.classList.add('visible');
        }, 10);
        
        // Focar no botão de fechar para acessibilidade
        setTimeout(() => {
            closeButton.focus();
        }, 100);
        
        // Anunciar para leitores de tela
        announceToScreenReader('Imagem ampliada aberta. Pressione Escape ou o botão fechar para sair.');
        
        // Manipuladores de eventos para fechar o modal
        closeButton.addEventListener('click', closeModal);
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                closeModal();
            }
        });
        
        // Fechar com tecla Escape
        document.addEventListener('keydown', function escapeListener(e) {
            if (e.key === 'Escape') {
                closeModal();
                document.removeEventListener('keydown', escapeListener);
            }
        });
        
        function closeModal() {
            modal.classList.remove('visible');
            setTimeout(() => {
                document.body.removeChild(modal);
                // Retornar foco à imagem original
                this.focus();
            }, 300);
            announceToScreenReader('Imagem ampliada fechada.');
        }
    }
    
    /**
     * Configura anúncios para mudanças de aba
     */
    function setupTabAnnouncements() {
        if (!tabButtons.length) return;
        
        tabButtons.forEach(button => {
            button.addEventListener('shown.bs.tab', function(e) {
                const targetId = e.target.getAttribute('aria-controls');
                const targetContent = document.getElementById(targetId);
                const tabName = e.target.textContent.trim();
                
                announceToScreenReader(`Aba ${tabName} ativada`);
            });
        });
    }
    
    /**
     * Configura controles para GIF (pausa/reprodução)
     */
    function setupGifControls() {
        if (!tutorialGif) return;
        
        // Criar contêiner para controles
        const controlsContainer = document.createElement('div');
        controlsContainer.className = 'tutorial-controls';
        
        // Criar botão de pausa/reprodução
        const toggleButton = document.createElement('button');
        toggleButton.className = 'tutorial-control-btn';
        toggleButton.innerHTML = '<i class="fas fa-pause me-2"></i>Pausar animação';
        toggleButton.setAttribute('aria-label', 'Pausar animação do tutorial');
        
        // Criar botão para alternar para imagens estáticas
        const switchButton = document.createElement('button');
        switchButton.className = 'tutorial-control-btn';
        switchButton.innerHTML = '<i class="fas fa-images me-2"></i>Ver passo a passo';
        switchButton.setAttribute('aria-label', 'Alternar para tutorial passo a passo com imagens estáticas');
        
        // Adicionar botões ao contêiner
        controlsContainer.appendChild(toggleButton);
        controlsContainer.appendChild(switchButton);
        
        // Inserir controles após o GIF
        const gifContainer = tutorialGif.parentElement;
        gifContainer.parentElement.insertBefore(controlsContainer, gifContainer.nextSibling);
        
        // Salvar URL original do GIF
        const originalSrc = tutorialGif.src;
        let isPaused = false;
        
        // Manipulador para botão de pausa/reprodução
        toggleButton.addEventListener('click', function() {
            if (isPaused) {
                // Reproduzir GIF
                tutorialGif.src = originalSrc;
                toggleButton.innerHTML = '<i class="fas fa-pause me-2"></i>Pausar animação';
                toggleButton.setAttribute('aria-label', 'Pausar animação do tutorial');
                announceToScreenReader('Animação do tutorial reproduzindo');
            } else {
                // Pausar GIF (substituindo por um frame estático)
                createStaticFrame();
                toggleButton.innerHTML = '<i class="fas fa-play me-2"></i>Reproduzir animação';
                toggleButton.setAttribute('aria-label', 'Reproduzir animação do tutorial');
                announceToScreenReader('Animação do tutorial pausada');
            }
            isPaused = !isPaused;
        });
        
        // Manipulador para botão de alternar para imagens estáticas
        switchButton.addEventListener('click', function() {
            // Ativar a aba de passo a passo
            const stepByStepTab = document.getElementById('step-by-step-tab');
            if (stepByStepTab) {
                const tabInstance = new bootstrap.Tab(stepByStepTab);
                tabInstance.show();
            }
        });
        
        // Função para criar um frame estático do GIF
        function createStaticFrame() {
            // Criar um canvas para capturar o frame atual
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d');
            
            // Definir dimensões do canvas
            canvas.width = tutorialGif.naturalWidth || tutorialGif.width;
            canvas.height = tutorialGif.naturalHeight || tutorialGif.height;
            
            // Desenhar o frame atual no canvas
            context.drawImage(tutorialGif, 0, 0, canvas.width, canvas.height);
            
            // Substituir o GIF pelo frame estático
            try {
                tutorialGif.src = canvas.toDataURL('image/png');
            } catch (e) {
                console.error('Erro ao criar frame estático:', e);
                // Fallback: usar a primeira imagem estática do tutorial
                const firstStepImage = document.querySelector('.step-image');
                if (firstStepImage) {
                    tutorialGif.src = firstStepImage.src;
                }
            }
        }
    }
    
    /**
     * Configura navegação por teclado para o tutorial
     */
    function setupKeyboardNavigation() {
        // Adicionar navegação por teclado para os passos do tutorial
        const tutorialSteps = document.querySelectorAll('.tutorial-step');
        
        if (tutorialSteps.length) {
            tutorialSteps.forEach((step, index) => {
                // Adicionar atributos para acessibilidade
                step.setAttribute('tabindex', '0');
                step.setAttribute('role', 'region');
                step.setAttribute('aria-label', `Passo ${index + 1} do tutorial`);
                
                // Adicionar manipuladores de eventos para teclado
                step.addEventListener('keydown', function(e) {
                    // Navegar para o próximo passo com seta para baixo
                    if (e.key === 'ArrowDown' && index < tutorialSteps.length - 1) {
                        e.preventDefault();
                        tutorialSteps[index + 1].focus();
                        announceToScreenReader(`Navegando para o passo ${index + 2}`);
                    }
                    
                    // Navegar para o passo anterior com seta para cima
                    if (e.key === 'ArrowUp' && index > 0) {
                        e.preventDefault();
                        tutorialSteps[index - 1].focus();
                        announceToScreenReader(`Navegando para o passo ${index}`);
                    }
                });
            });
        }
    }
    
    /**
     * Configura descrições detalhadas para imagens
     */
    function setupDetailedDescriptions() {
        // Adicionar botão "Descrição detalhada" para cada imagem
        stepImages.forEach((image, index) => {
            // Criar botão de descrição detalhada
            const descButton = document.createElement('button');
            descButton.className = 'btn btn-sm btn-outline-primary mt-2';
            descButton.innerHTML = '<i class="fas fa-audio-description me-1"></i>Descrição detalhada';
            descButton.setAttribute('aria-label', 'Ouvir descrição detalhada da imagem');
            
            // Inserir botão após a imagem
            const imageContainer = image.parentElement;
            imageContainer.appendChild(descButton);
            
            // Obter descrição detalhada com base no índice da imagem
            const detailedDescription = getDetailedDescription(index);
            
            // Manipulador de clique para o botão
            descButton.addEventListener('click', function() {
                // Criar elemento para descrição detalhada
                const descriptionElement = document.createElement('div');
                descriptionElement.className = 'detailed-description alert alert-info mt-3';
                descriptionElement.setAttribute('role', 'region');
                descriptionElement.setAttribute('aria-live', 'polite');
                
                // Adicionar conteúdo da descrição
                descriptionElement.innerHTML = `
                    <h6 class="alert-heading">Descrição detalhada:</h6>
                    <p>${detailedDescription}</p>
                    <button class="btn btn-sm btn-outline-secondary mt-2 close-desc">Fechar descrição</button>
                `;
                
                // Verificar se já existe uma descrição aberta
                const existingDesc = imageContainer.querySelector('.detailed-description');
                if (existingDesc) {
                    existingDesc.remove();
                } else {
                    // Inserir descrição após o botão
                    imageContainer.appendChild(descriptionElement);
                    
                    // Anunciar para leitores de tela
                    announceToScreenReader('Descrição detalhada aberta');
                    
                    // Manipulador para botão de fechar
                    const closeButton = descriptionElement.querySelector('.close-desc');
                    closeButton.addEventListener('click', function() {
                        descriptionElement.remove();
                        announceToScreenReader('Descrição detalhada fechada');
                    });
                }
            });
        });
    }
    
    /**
     * Obtém descrição detalhada para uma imagem com base no índice
     */
    function getDetailedDescription(index) {
        // Descrições detalhadas para cada passo do tutorial
        const descriptions = [
            "Nesta imagem, vemos a interface do Zoom com foco na barra de ferramentas inferior. A barra é cinza escura e contém vários ícones. No canto esquerdo, há um ícone de microfone, que controla o áudio da reunião. Ao lado do ícone de microfone, há uma pequena seta apontando para cima. Esta seta, quando clicada, abre um menu suspenso com opções relacionadas ao áudio. No menu suspenso aberto, podemos ver várias opções, incluindo 'Configurações de Áudio', que é a opção que deve ser selecionada para acessar as configurações completas de áudio do Zoom.",
            
            "Esta imagem mostra a janela de configurações de áudio do Zoom. A janela tem um fundo cinza claro com várias seções. Na parte superior, há uma barra lateral com diferentes categorias de configurações, com 'Áudio' selecionado. Na seção principal, vemos as configurações de microfone. Há um menu suspenso que permite selecionar o dispositivo de entrada de áudio (microfone) desejado. Abaixo do menu, há uma barra de nível que mostra a intensidade do áudio captado pelo microfone, permitindo verificar se o microfone está funcionando corretamente. A barra se move quando há som sendo captado. Há também opções adicionais como 'Ajustar automaticamente o volume do microfone' e 'Suprimir ruído de fundo'.",
            
            "Nesta imagem, vemos a continuação da janela de configurações de áudio do Zoom, focando na seção de alto-falantes. Similar à seção de microfone, há um menu suspenso que permite selecionar o dispositivo de saída de áudio (alto-falante) desejado. Abaixo do menu, há um botão 'Testar Alto-falante' que, quando clicado, reproduz um som de teste para verificar se o alto-falante selecionado está funcionando corretamente. Há também um controle deslizante para ajustar o volume de saída. Na parte inferior da janela, há botões para cancelar ou salvar as configurações realizadas."
        ];
        
        // Retornar descrição correspondente ou uma mensagem padrão
        return descriptions[index] || "Descrição detalhada não disponível para esta imagem.";
    }
    
    /**
     * Anuncia mensagem para leitores de tela
     */
    function announceToScreenReader(message) {
        // Verificar se já existe um anunciador
        let announcer = document.getElementById('screen-reader-announcer');
        
        if (!announcer) {
            // Criar elemento anunciador
            announcer = document.createElement('div');
            announcer.id = 'screen-reader-announcer';
            announcer.setAttribute('aria-live', 'polite');
            announcer.setAttribute('aria-atomic', 'true');
            announcer.style.position = 'absolute';
            announcer.style.left = '-10000px';
            announcer.style.top = 'auto';
            announcer.style.width = '1px';
            announcer.style.height = '1px';
            announcer.style.overflow = 'hidden';
            
            // Adicionar ao corpo do documento
            document.body.appendChild(announcer);
        }
        
        // Limpar conteúdo anterior e adicionar nova mensagem
        announcer.textContent = '';
        
        setTimeout(() => {
            announcer.textContent = message;
        }, 100);
    }
});
