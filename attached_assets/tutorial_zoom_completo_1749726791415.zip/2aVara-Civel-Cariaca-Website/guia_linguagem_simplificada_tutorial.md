# Guia Simplificado para o Tutorial do Zoom

Este documento contém instruções simplificadas para o tutorial de configuração de áudio do Zoom, com foco em linguagem acessível para usuários leigos.

## Linguagem Recomendada

### Termos a evitar:
- Terminologia técnica complexa
- Siglas não explicadas
- Instruções vagas ou ambíguas

### Termos a utilizar:
- Explicações passo a passo
- Analogias com objetos cotidianos
- Confirmações visuais claras

## Exemplos de Instruções Simplificadas

### Passo 1: Acessar as configurações de áudio
**Versão técnica:** "Acesse o menu dropdown adjacente ao ícone de microfone para selecionar as configurações de áudio."

**Versão simplificada:** "Procure o desenho de um microfone na parte de baixo da tela. Ao lado dele, há uma setinha apontando para cima. Clique nessa setinha e escolha a opção 'Configurações de Áudio'."

### Passo 2: Configurar o microfone
**Versão técnica:** "Selecione o dispositivo de entrada de áudio apropriado e verifique se o nível de entrada está registrando."

**Versão simplificada:** "Na janela que abriu, escolha qual microfone você quer usar na lista que aparece. Fale algo em voz alta e observe se a barra colorida se move quando você fala. Se a barra se mover, seu microfone está funcionando corretamente."

### Passo 3: Configurar os alto-falantes
**Versão técnica:** "Selecione o dispositivo de saída de áudio e teste a reprodução."

**Versão simplificada:** "Na mesma janela, escolha quais alto-falantes ou fones de ouvido você quer usar. Clique no botão 'Testar Alto-falante' para ouvir um som de teste. Se você ouvir o som, seus alto-falantes estão funcionando corretamente."

## Dicas para Explicações Visuais

1. **Use referências de cores e formas:** "Procure o botão azul redondo com um desenho de microfone"

2. **Indique posições claramente:** "No canto inferior esquerdo da tela" em vez de "na região inferior"

3. **Forneça confirmações visuais:** "Quando estiver correto, você verá uma marca de verificação verde"

4. **Use analogias:** "A barra de volume funciona como um termômetro - quanto mais alta, mais forte é o som"

## Perguntas Frequentes Simplificadas

1. **"O que fazer se ninguém me ouve?"**
   Resposta: "Primeiro, verifique se o microfone não está silenciado (deve haver um risco vermelho sobre o ícone do microfone se estiver silenciado). Depois, verifique se escolheu o microfone certo na lista."

2. **"Não consigo ouvir os outros participantes"**
   Resposta: "Primeiro, verifique se o volume do seu computador está ligado. Depois, verifique se escolheu os alto-falantes corretos na lista. Tente aumentar o volume usando os controles do seu computador."

## Recomendações para Tutoriais em Vídeo/GIF

1. **Velocidade:** Manter ritmo lento para permitir acompanhamento
2. **Destaques:** Usar círculos ou setas para indicar onde clicar
3. **Pausas:** Inserir momentos de pausa após cada ação importante
4. **Repetição:** Mostrar ações críticas mais de uma vez

## Verificação de Compreensão

Ao final de cada seção principal, incluir perguntas simples como:
- "Conseguiu encontrar o botão do microfone?"
- "A barra colorida se move quando você fala?"
- "Conseguiu ouvir o som de teste?"
